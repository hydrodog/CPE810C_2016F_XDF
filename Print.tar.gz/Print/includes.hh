
/*This is a list of all includes documents.
 * Author: @Zejian Zhou(Github:JayZejianZhou) @Fan Yang(Github:fyang14)
 * Edited at 11/10,2016
 */



#ifndef INCLUDES_HH
#define INCLUDES_HH


#include "dialog.h"
#include <QApplication>
#include <list>
#include <QRectF>
#include <QPainter>


#include "page.h"
#include "frame.h"

#include "ppage.h"
#include "pprint.hh"
#include "pframe.h"





#endif // INCLUDES_HH
